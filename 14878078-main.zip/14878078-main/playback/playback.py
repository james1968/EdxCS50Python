entry = input("Enter your comment: ")
ans = entry.replace(" ", "...")
print(ans)