welcome = input("Enter welcome: ")
ans = welcome.lower()
print(ans)