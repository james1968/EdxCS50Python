mass = input("m: ")
c = 3 * 10 ** 8
c_square = c * c
energy = int(mass) * c_square
print(energy)