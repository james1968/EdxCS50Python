import emoji

word = input("Enter word: ")

print(emoji.emojize(f'{word}'))