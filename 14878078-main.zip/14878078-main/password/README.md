Random Password Generator
    #### Video Demo:  <URL HERE>
    #### Description: Random Password Generator

This programme has been designed to allow a user to generate a random password.  The user can sepcific whether, an addition to alphabet charaters, both upper and lower case, whether they want to also include numbers and special characters.
Once the user has defined there criteria they application will generate a random password based on the criteria.
For example if the user specificied "yes" to numbers and "yes" to special characters then a password such as the one below might be generated.

o6JfOXhLw8

Once the user has specified their requirements they can then decide whether or not they want to save the new passowrd to a file, along with a user specified account name.  They can also specify the file name that they want to use.

If the file already exists then the user can add new passwords to the existing file.  If the file is new then the file will be created.

In order to test the application there are tests to ensure that the lists that are used to generate the passowrd contain valid characters and also a test to ensure that the password is of the correct length.

As the password are random it is not possible to test the actual passowrds that are generated.

Fro future iterations I would like to amend the way the accounts and passwords are stored, ideally in a Dict and then allow the user the add new passwords to the file for the same account, so that this becomes a password management tool as well.