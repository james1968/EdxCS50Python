# this is a test file

def hello_world():
    print("Hello, world")

'''this is not a comment
and should be included
in the score'''